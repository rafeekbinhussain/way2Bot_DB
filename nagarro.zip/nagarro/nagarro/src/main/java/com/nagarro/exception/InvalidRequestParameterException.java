package com.nagarro.exception;

public class InvalidRequestParameterException extends Exception{

    public InvalidRequestParameterException(){super();}

    public InvalidRequestParameterException(String message){super(message);}

}
